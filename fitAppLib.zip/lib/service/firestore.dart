// import 'package:cloud_firestore/cloud_firestore.dart';

// class FirestoreService {
//   // Get collection of data
//   final CollectionReference notes =
//       FirebaseFirestore.instance.collection('notes');

//   // Add data
//   Future<void> addNote(String note) {
//     return notes.add({
//       'note': note,
//       'timestamp': Timestamp.now(),
//     });
//   }

//   // Read data
// }
